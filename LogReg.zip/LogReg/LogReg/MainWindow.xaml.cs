﻿using Microsoft.Win32;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace LogReg
{
    public partial class MainWindow : Window
    {
        private string username;
        private string password;
        private string catchphrase;
        private string imagePath;
        private string fileName { get; set; } = "nouser.png";

        private BitmapImage defaultImage { get; } = new BitmapImage(new Uri(Path.Combine(Path.Combine(Directory.GetCurrentDirectory(), "Resources"), "nouser.png")));

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ChoosePicture(object sender, RoutedEventArgs e)
        {
            // Configure open file dialog box
            var dialog = new Microsoft.Win32.OpenFileDialog();
            dialog.FileName = "Image"; // Default file name
            dialog.DefaultExt = ".png"; // Default file extension
            dialog.Filter = "Image Files (*.BMP;*.JPG;*.GIF)|*.PNG;*.JPG;*.GIF|All files (*.*)|*.*"; // Filter files by extension

            // Show open file dialog box
            bool? result = dialog.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                // Open document
                imagePath = dialog.FileName;
                
                // pokus o vyplnění objektu obrázkem
                BitmapImage img = new BitmapImage(new Uri(imagePath));
                circ_img.Fill = new ImageBrush(img);
            }
        }

        private void RegisterClick(object sender, RoutedEventArgs e)
        {
            username = txtb_reguser.Text;
            password = txtb_regpass.Text;
            catchphrase = txtb_regcatchphrase.Text;

            if (string.IsNullOrWhiteSpace(username)) { txtb_reg_error_output.Content = "Please fill in the Username."; }
            else if (string.IsNullOrWhiteSpace(password)) { txtb_reg_error_output.Content = "Please fill in the Password."; }
            else if (string.IsNullOrWhiteSpace(catchphrase)) { txtb_reg_error_output.Content = "Please fill in the Catchphrase."; }
            else
            {
                // Cíl: složka Resources ve vašem projektu
                string projectPath = Directory.GetCurrentDirectory();
                string resourcesPath = Path.Combine(projectPath, "Resources");

                // Vytvoření složky Resources, pokud neexistuje
                if (!Directory.Exists(resourcesPath))
                {
                    Directory.CreateDirectory(resourcesPath);
                }

                if (!string.IsNullOrEmpty(imagePath))
                {
                    // Určení cílové cesty
                    fileName = Path.GetFileName(imagePath);
                    string destinationFilePath = Path.Combine(resourcesPath, fileName);

                    // Kopírování souboru
                    File.Copy(imagePath, destinationFilePath, overwrite: true);
                }

                if (checkIfExists(username))
                {
                    txtb_reg_error_output.Content = "An account with this Username already exists.";
                }
                else
                {
                    // ukládání do csv
                    using (StreamWriter sw = new StreamWriter("my.csv", true))
                    {
                        sw.WriteLine($"{username},{password},{catchphrase},{fileName}");
                    }

                    txtb_reguser.Clear();
                    txtb_regpass.Clear();
                    txtb_regcatchphrase.Clear();
                    txtb_reg_error_output.Content = String.Empty;
                    circ_img.Fill = new ImageBrush(defaultImage);

                    MessageBox.Show("Registration complete, you can log in.", ":)", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void LoginClick(object sender, RoutedEventArgs e)
        {
            username = txtb_username.Text;
            password = txtb_password.Text;

            if (string.IsNullOrWhiteSpace(username)) { txtb_error_output.Content = "Please fill in the Username."; }
            else if (string.IsNullOrWhiteSpace(password)) { txtb_error_output.Content = "Can't log in without a Password, silly."; }
            else
            {
                bool accountFound = false;

                // čtení cvs souboru
                using (StreamReader sr = new StreamReader("my.csv"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] cells = line.Split(',');

                        if (cells[0] == username && cells[1] == password)
                        {
                            accountFound = true;
                            fileName = cells[3];
                            catchphrase = cells[2];
                            break;
                        }
                    }
                }

                if (accountFound)
                {
                    string projectPath = Directory.GetCurrentDirectory();
                    string resourcesPath = Path.Combine(projectPath, "Resources");
                    imagePath = Path.Combine(resourcesPath, fileName);

                    // nové okýnko s účtem uživatele
                    UserAccount accountWindow = new UserAccount(username, catchphrase, imagePath);

                    accountWindow.Show();
                    Close();
                }
                else
                {
                    txtb_error_output.Content = "Invalid login credentials.";
                }
            }
        }

        private bool checkIfExists(string x)
        {
            using (StreamReader sr = new StreamReader("my.csv"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] cells = line.Split(',');

                    if (cells[0] == x)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
