﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LogReg
{
    /// <summary>
    /// Interaction logic for UserAccount.xaml
    /// </summary>
    public partial class UserAccount : Window
    {
        public UserAccount(string username, string catchphrase, string imagePath)
        {
            InitializeComponent();

            user_name.Text = username;
            user_catchphrase.Text = catchphrase;
            
            try
            {
                BitmapImage userImage = new BitmapImage(new Uri(imagePath));
                user_img.Fill = new ImageBrush(userImage);
            }
            catch
            {
                MessageBox.Show("Unable to load user image.", ":(", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void click_logout(object sender, RoutedEventArgs e)
        {
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            Close();
        }
    }
}
